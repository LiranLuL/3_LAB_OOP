#pragma once
#include "Card.h"
#include <iostream>
#include <ostream>
#include <fstream>

class Deck
{
public:
	Deck(const std::string& path);
	~Deck();
	void Deck_shuffler() const;
	friend std::ostream& operator<<(std::ostream& out, const Deck& deck);
	int Get_size() const { return _deck_size; }
	Card* Get_top_card();
	int Get_remains() const { return _remains; } 
	const std::string Get_random_suit();
private:
	Card* _all_cards = nullptr;
	int _remains;
	int _deck_size;
};

