#include "Mad.h"
#include <ctime>

Mad::Mad()
{
	_hand = new Card * [_how_i_have_cards];
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		_hand[i] = nullptr;
	}
}

Mad::~Mad()
{
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		_hand[i] = nullptr;
	}
}

bool Mad::Beat(const std::string& trump_suit, Card* card)
{
	bool can = false;
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		if (_hand[i] != nullptr)
		{
			if (_hand[i]->Get_suit() == card->Get_suit() && _hand[i]->Get_value() >= card->Get_value())
			{
				if (rand() % 2)
				{
					can = true;
					std::cout << "Next player beat it with: " << *_hand[i]<<"\n";
					_hand[i] = nullptr;
					break;
				}
			}
		}
	}
	return can;
}

Card* Mad::Put(const std::string& trump_suit)
{
	for (int i = _how_i_have_cards-1; i > -1; i--)
	{
		if (_hand[i] != nullptr)
		{
			_which_index = i;
			return _hand[i];
		}
	}
	return nullptr;
}

void Mad::Discard_card()
{
	_hand[_which_index] = nullptr;
}

bool Mad::My_hand_empty()
{
	bool flag = true;
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		if (_hand[i] != nullptr)
		{
			flag = false;
		}
	}
	return flag;
}

void Mad::Increase_hand(int how)
{
	Card** temp = new Card * [_how_cards_in_hands + how];
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		temp[i] = _hand[i];
		_hand[i] = nullptr;
	}
	for (int i = 0; i < how; i++)
	{
		temp[_how_i_have_cards + i] = nullptr;
	}
	_hand = temp;
	_how_i_have_cards += how;
}

void Mad::Take_card(Card* card)
{
	bool flag = false;
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		if (_hand[i] == nullptr)
		{
			_hand[i] = card;
			flag = true;
			break;
		}
	}
	if (!flag)
	{
		Increase_hand(1);
		_hand[_how_i_have_cards-1] = card;
	}
}
