#include "Table.h"

Table::~Table()
{
	if (_card_on_table != nullptr)
	{
		_card_on_table = nullptr;
	}
}

Card* Table::What_card_on_table()
{
	return _card_on_table;
}

void Table::Put_card_on_table(Card* card)
{
	_card_on_table = card;
}

