#include "Card_game.h"
#include <sstream>


Card_game::~Card_game()
{
	Clean_players();
	if(_deck!=nullptr)
	delete _deck;
	if(table!=nullptr)
	delete table;
}

void Card_game::Deck_reader(const std::string& path)
{
	_deck = new Deck(path);
}

Human* Card_game::Human_factory(int which)
{
	Human* player;
	switch (which)
	{
	case 1:
		player = new Mad;
		break;
	case 2:
		player = new Honest;
		break;
	case 3:
		player = new Greedy;
		break;
	default:
		throw std::exception("player isnt create");
	}
	return player;
}

void Card_game::Add_players(int how, int* characters)
{
	if (how <= _deck->Get_size() / _how_cards_in_hands)
	{
		Clean_players();
		_how_players = how;
		_players = new Human * [how];
		for (int i = 0; i < how; i++)
		{
			_players[i] = Human_factory(characters[i]);
		}
	}
	else
	{
		throw std::exception("Many players");
	}
}

bool Card_game::Check_hands(Human** _players, int how) const
{
	int answer = 0, res = 0;

	for (int i = 0; i < how; i++)
	{
		for (int j = 0; j < _players[i]->_how_i_have_cards; j++)
		{
			if (_players[i]->_hand[j] == nullptr)
			{
				res++;
			}
		}
		if (res == _players[i]->_how_i_have_cards)
		{
			answer++;
		}
		res = 0;
	}
	if (answer >= how - 1)
	{
		return false;
	}
	else
	{
		return true;
	}
}

int Card_game::First_turn(Human** _players, int which, Table* table, int how) const
{
	Card* temp = _players[which]->Put(_trump_suit);
	if (temp == nullptr)
	{
		return -1;
	}
	for (int i = 1; i < _how_players; i++)
	{
		if (!_players[(which + i) % how]->My_hand_empty())
		{
			table->Put_card_on_table(temp);
			std::cout << "Player " << which << " put: " << *table->What_card_on_table() << "\n";
			return i;
		}
	}
}

bool Card_game::Second_turn(Human** _players, int which, Table* table, const std::string& trump_suit)
{
	return _players[which]->Beat(trump_suit, table->What_card_on_table());
}

Human* Card_game::Define_winner(Card* card, Human** _players, int how_players) const
{
	int res = 0;
	Human* winner = nullptr;
	if (card == nullptr)
	{
		for (int i = 0; i < how_players; i++)
		{
			if (_players[i]->My_hand_empty())
			{
				res++;
			}
		}
		if (res >= how_players-1)
		{
			for (int i = 0; i < how_players; i++)
			{
				if (_players[i]->My_hand_empty())
				{
					winner = _players[i];
				}
			}
		}
		res = 0;
		return winner;
	}

}

Human* Card_game::Start_game()
{
	if (_players != nullptr)
	{
		_trump_suit = _deck->Get_random_suit();
		for (int i = 0; i < 15; i++)
		{
			_deck->Deck_shuffler();
		}
		Fill_hands(_players);
		table = new Table;
		int result, tmp;
		int index = 0;
		Human* winner;
		winner = nullptr;
		while (Check_hands(_players, _how_players))// ���� � 3 �� 4 ���� ����� => ������
		{
			Fill_hands(_players); //������ ��� ��������� 4 ������ ����� � ����
			tmp = First_turn(_players, index % _how_players, table, _how_players);//������ ������ ���������� ����� ������
			if (tmp == -1)
			{
				index++;
				continue;
			}
			index += tmp;
			result = Second_turn(_players, (index) % _how_players, table, _trump_suit);

			if (!result)
			{
				std::cout << "Player " << index % _how_players << " grab card\n";
				_players[(index) % _how_players]->Take_card(table->What_card_on_table());
				_players[(index - tmp) % _how_players]->Discard_card();
				index++;
			}
			else
			{
				_players[(index - tmp) % _how_players]->Discard_card();
			}
			winner = Define_winner(_deck->Get_top_card(), _players, _how_players);
			if (index % 5 == 0)
			{
				Shuffle_hands(_players, _how_players);
			}
		}
		//1 ����� �� 2
		//���� �������� �� ����������
		//���� ������������ ����
		//� 3 ������� �� �������� �����
		return winner;
	}
}

void Card_game::Shuffle_hands(Human** _players, int how_players) const
{
	for (int i = 0; i < how_players; i++)
	{
		int n = _players[i]->_how_i_have_cards;
		if (n < 2)
		{
			break;
		}
		while (n > 1)
		{
			int ind = rand() % n;
			n--;
			Card* temp = _players[i]->_hand[n];
			_players[i]->_hand[n] = _players[i]->_hand[ind];
			_players[i]->_hand[ind] = temp;
		}
	}
}

void Card_game::Fill_hands(Human** _players) const
{
	int count = 0;
	for (int i = 0; i < _how_players; i++)
	{
		for (int j = 0; j < _players[i]->_how_i_have_cards; j++)
		{
			if (_players[i]->_hand[j] != nullptr)
			{
				count++;
			}
		}

		if (count < _how_cards_in_hands)
		{
			for (int j = 0; j < _how_cards_in_hands; j++)
			{
				if (_players[i]->_hand[j] == nullptr)
				{
					_players[i]->_hand[j] = _deck->Get_top_card();
				}
			}
		}
		count = 0;
	}
}

void Card_game::Clean_players()
{
	if (_players != nullptr)
	{
		for (int i = 0; i < _how_players; i++)
		{
			if (_players[i] != nullptr)
			{
				delete[] _players[i];
			}
		}
		delete[] _players;
	}
}
