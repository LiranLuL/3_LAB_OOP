#include "Console_interactor.h"
#define new new( _NORMAL_BLOCK, __FILE__, __LINE__)

void Console_interactor::Run()
{
	int command = 1;

	Card_game* my_game = new Card_game;
	std::cout << "Enter the number of cards in the deck(32 or 52 or 104):\n";
	std::string path;
	std::cin >> path;
	path += ".txt";
	try
	{
		int how;
		my_game->Deck_reader(path);
		std::cout << "How players?\n";
		std::cin >> how;
		int* characters = new int[how];
		std::cout << "1-mad\n2-honest\n3-greedy\nEnter characters through a space\n";
		for (int i = 0; i < how; i++)
		{
			std::cin >> characters[i];
		}
		my_game->Add_players(how, characters);
		delete[] characters;
	}
	catch (const std::exception& err)
	{
		std::cerr << "Error: " << err.what();
		exit(1);
	}

	int how;
	srand((unsigned int)time(NULL) / 2);
	std::cout << "1 - Add players\n2 - Start game \n3 - Change deck\n4 - \n5 - \n0 - Exit.\n";
	std::cout << "Enter a command: ";

	while (command)
	{
		std::cout << "Enter a command: ";
		std::cin >> command;
		switch (command)
		{
		case 0:
		{
			delete my_game;
			break;
		}
		case 1:
		{
			try
			{
				std::cout << "How?\n";
				std::cin >> how;
				int* characters = new int[how];
				std::cout << "1-mad\n2-honest\n3-greedy\nEnter characters through a space\n";
				for (int i = 0; i < how; i++)
				{
					std::cin >> characters[i];
				}
				my_game->Add_players(how, characters);
				delete[] characters;
			}
			catch (std::exception& ex)
			{
				std::cout << ex.what();
				exit(1);
			}
		}
		break;
		case 2:
		{
			//	32
			//	2
			//	1 3
			//	2 
			try
			{
				srand((unsigned int)time(NULL) / 2);
				Human* winner = my_game->Start_game();
				std::cout << "\nWinner: \n";
				std::cout << typeid(*winner).name() << "\n";
				std::cout << "\n";
			}
			catch (std::exception& ex)
			{
				std::cout << ex.what();
			}
			break;
		}
		case 3:
		{
			std::cout << "Enter the number of cards in the deck(32 or 52 or 104):\n";
			std::string path;
			std::cin >> path;
			path += ".txt";
			try
			{
				my_game->Deck_reader(path);
			}
			catch (const std::exception& err)
			{
				std::cerr << "Error: " << err.what();
				exit(1);
			}
		}
		break;
		case 4:
		{
			//52
			//1
			//4
			//1 2 3 2
			//4


			break;
		}
		case 5:
			break;
		default:
			std::cout << "Invalid command. Try again.\n";
			break;
		}

	}
}
