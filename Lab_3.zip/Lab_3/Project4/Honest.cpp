#include "Honest.h"
#include <ctime>

Honest::Honest()
{
	_hand = new Card * [_how_i_have_cards];
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		_hand[i] = nullptr;
	}
}

Honest::~Honest()
{
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		_hand[i] = nullptr;
	}
}

bool Honest::My_hand_empty()
{
	bool flag = true;
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		if (_hand[i] != nullptr)
		{
			flag = false;
		}
	}
	return flag;
}

void Honest::Discard_card()
{
	_hand[_which_index] = nullptr;
}

bool Honest::Beat(const std::string& trump_suit, Card* card)
{
	bool can = false;
	for (int i = _how_i_have_cards - 1; i > -1; i--)
	{
		if (_hand[i] != nullptr)
		{
			if (_hand[i]->Get_suit() == card->Get_suit() && _hand[i]->Get_value() >= card->Get_value())
			{
				if (_hand[i]->Get_suit() == card->Get_suit() && _hand[i]->Get_value() >= card->Get_value())
				{
					can = true;
					std::cout << "Next player beat it with: " << *_hand[i] << "\n";
					_hand[i] = nullptr;
					break;
				}
			}
		}
	}
	return can;
}

Card* Honest::Put(const std::string& trump_suit)
{
	for (int i = _how_i_have_cards - 1; i > -1; i--)
	{
		if (_hand[i] != nullptr)
		{
			_which_index = i;
			return _hand[i];
		}
	}
	return nullptr;
}


void Honest::Increase_hand(int how)
{
	Card** temp = new Card * [_how_cards_in_hands + how];
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		temp[i] = _hand[i];
		_hand[i] = nullptr;
	}
	for (int i = 0; i < how; i++)
	{
		temp[_how_i_have_cards + i] = nullptr;
	}
	_hand = temp;
	_how_i_have_cards += how;
}

void Honest::Take_card(Card* card)
{
	bool flag = false;
	for (int i = 0; i < _how_i_have_cards; i++)
	{
		if (_hand[i] == nullptr)
		{
			_hand[i] = card;
			flag = true;
			break;
		}
	}
	if (!flag)
	{
		Increase_hand(1);
		_hand[_how_i_have_cards - 1] = card;
	}
}
