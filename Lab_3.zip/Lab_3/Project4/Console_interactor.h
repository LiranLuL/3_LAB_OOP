#pragma once
#include <iostream>
#include "Card_game.h"
#include <ctime>
#include <typeinfo>

class Console_interactor
{
public:
	void Run();
};

